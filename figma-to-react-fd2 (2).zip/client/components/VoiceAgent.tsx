import { useState } from "react";

export default function VoiceAgent() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
      {/* Speech bubble */}
      {isOpen && (
        <div className="relative flex items-center">
          {/* Message box */}
          <div className="bg-white rounded-[8px] shadow-lg px-3 py-2 w-[199px]">
            <p
              className="text-black text-[14px] font-normal leading-snug"
              style={{ fontFamily: "Poppins, sans-serif" }}
            >
              Hi! I'm your Voice Agent.{" "}
              <br />
              How can I help you today?
            </p>
          </div>

          {/* Arrow pointing right toward avatar */}
          <svg
            width="10"
            height="8"
            viewBox="0 0 10 8"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="flex-shrink-0"
          >
            <path
              d="M0 0C0 0 2.84229 1.92341 4.73684 2C6.83246 2.08472 10 0 10 0V8C10 8 6.81495 6.4358 4.73684 6.5C2.86172 6.55793 0 8 0 8V0Z"
              fill="white"
            />
          </svg>

        </div>
      )}

      {/* Agent avatar button */}
      <button
        onClick={() => setIsOpen((o) => !o)}
        className="relative w-[45px] h-[42px] rounded-full flex items-center justify-center focus:outline-none"
        aria-label="Voice agent"
      >
        <div className="w-[45px] h-[42px] rounded-full bg-white shadow-[0_4px_16px_0_rgba(0,0,0,0.18)] flex items-center justify-center overflow-hidden">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/faa0fd51a66242646990ec8debf5f26867cb8a12?width=50"
            alt="Voice Agent"
            className="w-full h-full object-cover rounded-full"
          />
        </div>
      </button>
    </div>
  );
}
