import { useState } from "react";
import { cn } from "@/lib/utils";

interface FoodCardProps {
  id: number;
  name: string;
  description: string;
  price: number;
  available: boolean;
  image: string;
}

export default function FoodCard({ id, name, description, price, available, image }: FoodCardProps) {
  const [quantity, setQuantity] = useState(0);

  const increment = () => setQuantity((q) => q + 1);
  const decrement = () => setQuantity((q) => Math.max(0, q - 1));

  return (
    <div className="flex-shrink-0 w-[207px] rounded-[5px] border border-[#ECECEC] bg-[#F3F3F3] flex flex-col overflow-hidden">
      {/* Food image */}
      <div className="relative">
        <img
          src={image}
          alt={name}
          className="w-full h-[87px] object-cover rounded-[6px] px-[6px] pt-[9px]"
        />
      </div>

      {/* Content */}
      <div className="px-[6px] pt-2 pb-[6px] flex flex-col gap-1 flex-1">
        <h3
          className="text-black font-semibold text-[14px] leading-[14px]"
          style={{ fontFamily: "Poppins, sans-serif" }}
        >
          {name}
        </h3>
        <p
          className="text-[#676767] text-[9px] leading-normal line-clamp-3"
          style={{ fontFamily: "Poppins, sans-serif" }}
        >
          {description}
        </p>
      </div>

      {/* Price + availability row */}
      <div className="px-[6px] flex items-center justify-between mt-1">
        <span
          className="text-black font-semibold text-[14px] leading-[14px]"
          style={{ fontFamily: "Poppins, sans-serif" }}
        >
          Rs. {price}
        </span>
        <div
          className={cn(
            "flex items-center gap-1 px-2 py-[2px] rounded-full text-white text-[10px] font-medium",
            available ? "bg-[#00A01D]" : "bg-[#FF0000]"
          )}
          style={{ fontFamily: "Rubik, sans-serif" }}
        >
          <span
            className="w-[6px] h-[6px] rounded-full bg-white flex-shrink-0"
          />
          {available ? "Available" : "Not Available"}
        </div>
      </div>

      {/* Quantity controls */}
      <div className="px-[6px] pb-[6px] mt-[6px]">
        <div className="flex items-center bg-white rounded-[3px] overflow-hidden h-[26px]">
          {/* Minus */}
          <button
            onClick={decrement}
            className="w-[28px] h-full bg-[#F2F2F2] flex items-center justify-center flex-shrink-0 hover:bg-gray-200 transition-colors"
            aria-label="Decrease quantity"
          >
            <span className="text-black text-sm font-medium leading-none">−</span>
          </button>

          {/* Quantity display */}
          <div className="flex-1 flex items-center justify-center h-full border border-[#F4F4F4] bg-[#F9F9F9]">
            <span
              className="text-black text-[14px] font-normal"
              style={{ fontFamily: "Rubik, sans-serif" }}
            >
              {quantity}
            </span>
          </div>

          {/* Plus */}
          <button
            onClick={increment}
            className="w-[28px] h-full bg-[#FF3400] flex items-center justify-center flex-shrink-0 hover:bg-[#e02d00] transition-colors"
            aria-label="Increase quantity"
          >
            <span
              className="text-white text-[16px] font-medium leading-none"
              style={{ fontFamily: "Rubik, sans-serif" }}
            >
              +
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
