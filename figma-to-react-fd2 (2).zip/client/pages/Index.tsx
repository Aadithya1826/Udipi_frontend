import { useState } from "react";
import FoodCard from "@/components/FoodCard";
import CategoryTabs from "@/components/CategoryTabs";
import VoiceAgent from "@/components/VoiceAgent";
import { cn } from "@/lib/utils";

interface Category {
  id: string;
  name: string;
  image?: string;
}

const CATEGORIES: Category[] = [
  { id: "all", name: "All Menu" },
  {
    id: "breakfast",
    name: "Breakfast",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/1820b89024cc5339a94c47a80adb10aba6f8042d?width=56",
  },
  {
    id: "lunch",
    name: "Lunch",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/9a0ee0aa828487dab39d472d95da26cf07415c74?width=60",
  },
  {
    id: "dinner",
    name: "Dinner",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/b29b2b7f3ac77a57378cb8482c26a44dbcc68c6d?width=60",
  },
  {
    id: "dosa",
    name: "Dosa Items",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/2d500d13886ec067b22dd67f6a166c11b0f9b45d?width=60",
  },
  {
    id: "idli",
    name: "Idli Vada",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/2e33ba47525f4b4a1a67e5b5a5a09bffae15ff40?width=60",
  },
  {
    id: "rice",
    name: "Rice Varieties",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/0edd96fa4b3ffa901423fd4881c6d955491e6e1a?width=60",
  },
  {
    id: "snacks",
    name: "Evening Snacks",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/27367cc54b8e147348fc3e7f4204f887f2ac8e8e?width=60",
  },
  {
    id: "south-indian",
    name: "South Indian",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/b7f61cea92a021e054d08237df9cdd97ba3983dd?width=60",
  },
  {
    id: "north-indian",
    name: "North Indian",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=60",
  },
  {
    id: "beverages",
    name: "Hot Beverages",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/58ad416ecf88446de0263b4c58f739ac0367dc85?width=76",
  },
  {
    id: "soups",
    name: "Soups",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/c510db97793b377653fc5f0c65b8c4d15a824066?width=64",
  },
  {
    id: "salads",
    name: "Salads",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=62",
  },
  {
    id: "raita",
    name: "Raitha",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=62",
  },
  {
    id: "tandoori-breads",
    name: "Tandoori Breads",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=68",
  },
  {
    id: "tandoori-starters",
    name: "Tandoori Starters",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=68",
  },
  {
    id: "tandoori-sides",
    name: "Tandoori Sides",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=68",
  },
  {
    id: "noodles",
    name: "Noodles",
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=68",
  },
];

const FOOD_ITEMS = [
  {
    id: 1,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: true,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/24515a6ba5ae7a7103eb569ac70ab625c4a3912c?width=390",
  },
  {
    id: 2,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: true,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/24515a6ba5ae7a7103eb569ac70ab625c4a3912c?width=390",
  },
  {
    id: 3,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: false,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/5e22dca9c09b6929a741f7d9a1072d953de425f9?width=390",
  },
  {
    id: 4,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: true,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=390",
  },
  {
    id: 5,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: true,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/196e409dd6d471ffa557ac7b37892e488040a985?width=390",
  },
  {
    id: 6,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: true,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=390",
  },
  {
    id: 7,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: true,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/908f34b5767649e86bf184ed5278b70287ac66e8?width=390",
  },
  {
    id: 8,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: true,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/a0aec7389b59c267fe9e6cb147a75e605ac97963?width=390",
  },
  {
    id: 9,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: true,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/af25bfb2c290d0b374e298d7ddf63af699c99df4?width=390",
  },
  {
    id: 10,
    name: "Onion Rava Dosa",
    description: "semolina (rava), rice flour, maida, curd, and spices, which is then poured onto a hot tawa with finely chopped onions",
    price: 100,
    available: false,
    image: "https://api.builder.io/api/v1/image/assets/TEMP/af25bfb2c290d0b374e298d7ddf63af699c99df4?width=390",
  },
];

export default function Index() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="min-h-screen bg-white">
      {/* Background blur image */}
      <div
        className="fixed inset-0 -z-10 w-full h-full opacity-5"
        style={{
          backgroundImage:
            "url(https://api.builder.io/api/v1/image/assets/TEMP/482303ed61e5f55eb7582b09e22ac67f4dc89bfa?width=3326)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          filter: "blur(52px)",
        }}
      />

      <div className="relative">
        {/* Top Header Bar */}
        <div className="bg-white border-b border-[#EBEBF1] px-6 py-4 flex items-center justify-between flex-wrap gap-4">
          {/* Logo and branding */}
          <div className="flex items-center gap-3">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/cafe29b14c4a52be2fa839658e3f4cbc44c92725?width=94"
              alt="DATA UDIPI"
              className="w-12 h-10"
            />
            <div className="flex flex-col items-start">
              <h1
                className="text-white text-2xl font-normal leading-none"
                style={{
                  fontFamily: "Malayalam MN, sans-serif",
                  textShadow: "0 2px 4px rgba(0, 0, 0, 0.26)",
                  WebkitTextStroke: "1px white",
                  color: "white",
                }}
              >
                DATA UDIPI
              </h1>
            </div>
          </div>

          {/* Search + controls section */}
          <div className="flex items-center gap-3">
            {/* Search bar */}
            <div className="flex items-center gap-2 bg-[rgba(243,243,243,0.31)] border border-[#E7EAF3] rounded-[19px] px-4 py-2">
              <svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.23926 -1C8.32122 -0.999992 9.39297 -0.787097 10.3926 -0.373047C11.3921 0.0410092 12.3004 0.648069 13.0654 1.41309C13.8305 2.17813 14.4375 3.08638 14.8516 4.08594C15.2656 5.08556 15.4785 6.15727 15.4785 7.23926C15.4785 8.32122 15.2656 9.39297 14.8516 10.3926C14.5657 11.0826 14.1847 11.7266 13.7266 12.3125L16.9951 15.5811C17.3855 15.9716 17.3856 16.6046 16.9951 16.9951C16.629 17.3612 16.05 17.3837 15.6572 17.0635L15.5811 16.9951L12.3125 13.7266C10.871 14.8539 9.08828 15.4785 7.23926 15.4785C5.05412 15.4785 2.95823 14.6105 1.41309 13.0654C-0.132048 11.5203 -0.999983 9.42441 -1 7.23926C-1 5.05409 -0.132063 2.95823 1.41309 1.41309C2.17813 0.648042 3.08637 0.0410101 4.08594 -0.373047C5.08556 -0.787105 6.15727 -1 7.23926 -1Z" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <input
                type="text"
                placeholder="Search for food......."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent text-[#8A8A8A] text-sm font-medium placeholder-[#8A8A8A] outline-none w-40"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              />
            </div>

            {/* New Order button */}
            <button className="flex items-center gap-2 bg-[rgba(4,157,71,0.14)] rounded-[19px] px-4 py-2 hover:bg-[rgba(4,157,71,0.2)] transition-colors">
              <span className="text-black text-lg font-normal leading-none" style={{ fontFamily: "Montserrat, sans-serif" }}>
                +
              </span>
              <span className="text-black text-sm font-medium" style={{ fontFamily: "Montserrat, sans-serif" }}>
                New Order
              </span>
            </button>

            {/* Filter button */}
            <button className="w-14 h-10 bg-[#F0F0F0] rounded-[11px] flex items-center justify-center hover:bg-gray-300 transition-colors">
              <svg width="22" height="10" viewBox="0 0 22 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1.01517 0H20.6418C20.911 0 21.1692 0.0790175 21.3596 0.21967C21.55 0.360322 21.6569 0.551088 21.6569 0.75C21.6569 0.948912 21.55 1.13968 21.3596 1.28033C21.1692 1.42098 20.911 1.5 20.6418 1.5H1.01517C0.74593 1.5 0.487717 1.42098 0.297336 1.28033C0.106955 1.13968 0 0.948912 0 0.75C0 0.551088 0.106955 0.360322 0.297336 0.21967C0.487717 0.0790175 0.74593 0 1.01517 0ZM4.06068 4.75C4.06068 4.55109 4.16763 4.36032 4.35801 4.21967C4.54839 4.07902 4.80661 4 5.07585 4H16.5811C16.8503 4 17.1085 4.07902 17.2989 4.21967C17.4893 4.36032 17.5963 4.55109 17.5963 4.75C17.5963 4.94891 17.4893 5.13968 17.2989 5.28033C17.1085 5.42098 16.8503 5.5 16.5811 5.5H5.07585C4.80661 5.5 4.54839 5.42098 4.35801 5.28033C4.16763 5.13968 4.06068 4.94891 4.06068 4.75ZM8.12135 8.75C8.12135 8.55109 8.22831 8.36032 8.41869 8.21967C8.60907 8.07902 8.86728 8 9.13652 8H12.5204C12.7897 8 13.0479 8.07902 13.2383 8.21967C13.4286 8.36032 13.5356 8.55109 13.5356 8.75C13.5356 8.94891 13.4286 9.13968 13.2383 9.28033C13.0479 9.42098 12.7897 9.5 12.5204 9.5H9.13652C8.86728 9.5 8.60907 9.42098 8.41869 9.28033C8.22831 9.13968 8.12135 8.94891 8.12135 8.75Z" fill="black" />
              </svg>
            </button>
          </div>

          {/* Right side: Date + Languages + Table + Time */}
          <div className="flex items-center gap-4 ml-auto">
            {/* Date */}
            <div className="hidden md:flex items-center gap-2 bg-[rgba(193,193,193,0.60)] rounded-[21px] px-4 py-2">
              <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="13" cy="13" r="13" fill="white" />
                <path fillRule="evenodd" clipRule="evenodd" d="M13 0C5.82037 0 0 5.82037 0 13C0 20.1796 5.82037 26 13 26C20.1796 26 26 20.1796 26 13C26 5.82037 20.1796 0 13 0ZM13.907 5.74419C13.907 5.50364 13.8114 5.27295 13.6413 5.10286C13.4712 4.93277 13.2405 4.83721 13 4.83721C12.7595 4.83721 12.5288 4.93277 12.3587 5.10286C12.1886 5.27295 12.093 5.50364 12.093 5.74419V13C12.093 13.5007 12.4993 13.907 13 13.907H20.2558C20.4964 13.907 20.7271 13.8114 20.8971 13.6413C21.0672 13.4712 21.1628 13.2405 21.1628 13C21.1628 12.7595 21.0672 12.5288 20.8971 12.3587C20.7271 12.1886 20.4964 12.093 20.2558 12.093H13.907V5.74419Z" fill="white" />
              </svg>
              <span className="text-black text-sm font-semibold" style={{ fontFamily: "Montserrat, sans-serif" }}>
                Tuesday, 10 March 2026
              </span>
            </div>

            {/* Languages button */}
            <button className="hidden lg:flex items-center gap-2 bg-white bg-opacity-[0.44] border border-white rounded-[15px] px-4 py-2 hover:bg-opacity-50 transition-colors">
              <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M7.75007 2C7.55116 2 7.36039 2.07902 7.21974 2.21967C7.07909 2.36032 7.00007 2.55109 7.00007 2.75C7.00007 2.94891 7.07909 3.13968 7.21974 3.28033C7.36039 3.42098 7.55116 3.5 7.75007 3.5H9.50007V4.251C9.50007 4.636 9.40307 4.93 9.27307 5.106C9.16207 5.257 9.01007 5.353 8.75807 5.353C8.55916 5.353 8.36839 5.43202 8.22774 5.57267C8.08709 5.71332 8.00807 5.90409 8.00807 6.103C8.00807 6.30191 8.08709 6.49268 8.22774 6.63333C8.36839 6.77398 8.55916 6.853 8.75807 6.853C9.0934 6.85942 9.4253 6.78466 9.72549 6.63508C10.0257 6.48551 10.2853 6.26557 10.4821 5.994C10.8491 5.494 11.0001 4.862 11.0001 4.251V2.75C11.0001 2.55109 10.9211 2.36032 10.7804 2.21967C10.6397 2.07902 10.449 2 10.2501 2H7.75007ZM6.69807 4.725C6.64295 4.58479 6.54688 4.46443 6.42238 4.3796C6.29788 4.29477 6.15072 4.2494 6.00007 4.2494C5.84942 4.2494 5.70225 4.29477 5.57775 4.3796C5.45325 4.46443 5.35719 4.58479 5.30207 4.725L2.04807 12.975C2.00898 13.0672 1.98873 13.1662 1.98853 13.2663C1.98832 13.3664 2.00816 13.4656 2.04687 13.5579C2.08558 13.6502 2.14238 13.7338 2.21392 13.8039C2.28547 13.8739 2.3703 13.9289 2.46344 13.9656C2.55657 14.0023 2.6561 14.02 2.75618 14.0177C2.85626 14.0153 2.95486 13.9929 3.04616 13.9519C3.13746 13.9108 3.21961 13.8519 3.28778 13.7786C3.35595 13.7053 3.40875 13.619 3.44307 13.525L4.24207 11.501H7.75507L8.55207 13.525C8.625 13.7101 8.76849 13.8587 8.95096 13.938C9.13343 14.0173 9.33995 14.0209 9.52507 13.948C9.71019 13.8751 9.85876 13.7316 9.93808 13.5491C10.0174 13.3666 10.021 13.1601 9.94807 12.975L6.69807 4.725ZM7.16407 10.001H4.83407L6.00007 7.045L7.16407 10.001ZM12.7501 2C12.949 2 13.1397 2.07902 13.2804 2.21967C13.4211 2.36032 13.5001 2.55109 13.5001 2.75V4.998H13.7501C13.949 4.998 14.1397 5.07702 14.2804 5.21767C14.4211 5.35832 14.5001 5.54909 14.5001 5.748C14.5001 5.94691 14.4211 6.13768 14.2804 6.27833C14.1397 6.41898 13.949 6.498 13.7501 6.498H13.5001V10.249C13.5001 10.4479 13.4211 10.6387 13.2804 10.7793C13.1397 10.92 12.949 10.999 12.7501 10.999C12.5512 10.999 12.3604 10.92 12.2197 10.7793C12.0791 10.6387 12.0001 10.4479 12.0001 10.249V2.75C12.0001 2.55109 12.0791 2.36032 12.2197 2.21967C12.3604 2.07902 12.5512 2 12.7501 2Z" fill="black" />
                </svg>
              </div>
              <span className="text-black text-base font-medium" style={{ fontFamily: "Montserrat, sans-serif" }}>
                Languages
              </span>
            </button>

            {/* Table number */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 border border-[#DFDFDF] rounded-[17px] px-3 py-2 bg-white">
                <span className="text-black text-base font-medium" style={{ fontFamily: "Montserrat, sans-serif" }}>
                  Table no :
                </span>
              </div>
              <div className="w-[59px] h-[59px] rounded-full bg-[#FF3400] flex items-center justify-center shadow-md">
                <span
                  className="text-white text-2xl font-normal"
                  style={{ fontFamily: "Malayalam MN, sans-serif" }}
                >
                  06
                </span>
              </div>
            </div>

            {/* Time */}
            <div className="hidden sm:flex items-center bg-[rgba(193,193,193,0.60)] rounded-[25px] px-4 py-2 gap-2">
              <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" clipRule="evenodd" d="M13 0C5.82037 0 0 5.82037 0 13C0 20.1796 5.82037 26 13 26C20.1796 26 26 20.1796 26 13C26 5.82037 20.1796 0 13 0ZM13.907 5.74419C13.907 5.50364 13.8114 5.27295 13.6413 5.10286C13.4712 4.93277 13.2405 4.83721 13 4.83721C12.7595 4.83721 12.5288 4.93277 12.3587 5.10286C12.1886 5.27295 12.093 5.50364 12.093 5.74419V13C12.093 13.5007 12.4993 13.907 13 13.907H20.2558C20.4964 13.907 20.7271 13.8114 20.8971 13.6413C21.0672 13.4712 21.1628 13.2405 21.1628 13C21.1628 12.7595 21.0672 12.5288 20.8971 12.3587C20.7271 12.1886 20.4964 12.093 20.2558 12.093H13.907V5.74419Z" fill="white" />
              </svg>
              <span className="text-black text-sm font-semibold" style={{ fontFamily: "Montserrat, sans-serif" }}>
                16:54 PM
              </span>
            </div>
          </div>
        </div>

        {/* Category Tabs Section */}
        <div className="bg-white border-b border-[#EBEBF1] px-6 py-4">
          <CategoryTabs
            categories={CATEGORIES}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
          />
        </div>

        {/* Main Content - Food Grid */}
        <div className="px-6 py-6">
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {FOOD_ITEMS.map((item) => (
              <FoodCard key={item.id} {...item} />
            ))}
          </div>

          {/* Progress indicator */}
          <div className="mt-6 flex items-center gap-4">
            <div className="w-96 h-[5px] rounded-full bg-[#EEE] overflow-hidden">
              <div className="h-full w-[33%] rounded-full bg-[#FF3400]" />
            </div>
          </div>
        </div>
      </div>

      {/* Voice Agent */}
      <VoiceAgent />
    </div>
  );
}
